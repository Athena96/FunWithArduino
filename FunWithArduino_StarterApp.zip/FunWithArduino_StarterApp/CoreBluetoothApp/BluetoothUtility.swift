//
//  BluetoothUtility.swift
//  CoreBluetoothApp
//
//  Created by Jared Franzone on 7/11/17.
//  Copyright © 2017 Jared Franzone. All rights reserved.
//

import Foundation
import CoreBluetooth


class BluetoothUtility: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    
    let ServiceUUID: CBUUID
    let CharacteristicUUID: CBUUID
    
    var centralManager: CBCentralManager?   // the iphone
    var discoveredPeripheral: CBPeripheral? // the motor/arduino
    var discoveredCharacteristic: CBCharacteristic? // the motor control characteristic
    
    init(serviceUUID: CBUUID, characteristicUUID: CBUUID) {
        self.ServiceUUID = serviceUUID
        self.CharacteristicUUID = characteristicUUID
        
        super.init()
        
        let queue = DispatchQueue(label: "com.new.CoreBluetoothApp", attributes: [])
        
        centralManager = CBCentralManager(delegate: self, queue: queue)
    }
    
    // MARK: - Private Helper functions
    
    func resetClass() {
        self.discoveredPeripheral = nil
        self.discoveredCharacteristic = nil
        postBluetoothStatusNotification(isConnected: false)
    }
    
    private func postBluetoothStatusNotification(isConnected status: Bool) {
        let connectionDetails = ["isConnected": status]
        NotificationCenter.default.post(name: Notification.Name(rawValue: "BluetoothConnectionStatus"), object: self, userInfo: connectionDetails)
    }
    
    
    // MARK: - CBCentralManager Delegate Methods
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            // TODO: Start Scanning for Peripherals
            break
        default:
            resetClass()
            break
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        // newly discovered peripheral is returned as a CBPeripheral object.
        // keep a strong reference to it
        self.discoveredPeripheral = peripheral
        self.centralManager?.stopScan() // to save battery
        
        // TODO: Connect to the Peripheral
    }
    
    /// #6
    // called becaue we previously called 'central.connect(...)'
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
  
        peripheral.delegate = self
        
        // TODO: Start looking for the service (ServiceUUID) we want to use
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        resetClass()
        
        // TODO (for later): Start scanning for Peripherals again
        
    }
    
    // MARK: - CBPeripheral Delegate Methods
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
  
        guard let motorControlService = peripheral.services?.first, error == nil else {
            print(error)
            resetClass()
            // TODO (for later): Start scanning for Peripherals again
            return
        }
        
        // TODO: Loop throught the peripherals services and if you find the one we want (ServiceUUID) initiate the process to start looking for the peripherals Characteristic we want to use (CharacteristicUUID)
        
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard let characteristics = service.characteristics, error == nil else {
            print(error)
            resetClass()
            // TODO (for later): Start scanning for Peripherals again
            return
        }
        
        // TODO: Loop throught the serives characteristics and if you find the one we want (CharacteristicUUID) we are good to go! save the characteristic in 'self.discoveredCharacteristic' and post our completion notification 'postBluetoothStatusNotification'
        
    }
}




