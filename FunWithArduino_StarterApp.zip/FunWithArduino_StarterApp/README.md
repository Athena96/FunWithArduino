# FunWithArduino
An iOS App that uses CoreBluetooth to control a servo motor connected to an Arduino with a Bluetooth Shield.
